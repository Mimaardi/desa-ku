<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
	<meta charset="UTF-8">
	
	<link rel="profile" href="//gmpg.org/xfn/11">
	<link media="all" href="https://kodesolution.com/wp-content/cache/autoptimize/1/css/autoptimize_e6cecaae710d5944bfdafd182d07f88e.css" rel="stylesheet" /><title>Page not found &#8211; KodeSolution Dot Net</title>
<script type="application/javascript">var MascotCoreAjaxUrl = "https://kodesolution.com/wp-admin/admin-ajax.php"</script><meta name='robots' content='max-image-preview:large' />
			<meta name="viewport" content="width=device-width, initial-scale=1">
					<link href="https://kodesolution.com/2022/oitech/wp-content/themes/oitech/assets/images/logo/favicon.png" rel="shortcut icon">
					<link href="https://kodesolution.com/2022/oitech/wp-content/themes/oitech/assets/images/logo/apple-touch-icon.png" rel="apple-touch-icon">
					<link href="https://kodesolution.com/2022/oitech/wp-content/themes/oitech/assets/images/logo/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
					<link href="https://kodesolution.com/2022/oitech/wp-content/themes/oitech/assets/images/logo/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
					<link href="https://kodesolution.com/2022/oitech/wp-content/themes/oitech/assets/images/logo/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">
		<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="KodeSolution Dot Net &raquo; Feed" href="https://kodesolution.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="KodeSolution Dot Net &raquo; Comments Feed" href="https://kodesolution.com/comments/feed/" />
<script type="text/javascript">
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/kodesolution.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.1.1"}};
/*! This file is auto-generated */
!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode,e=(p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0),i.toDataURL());return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(p&&p.fillText)switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([129777,127995,8205,129778,127999],[129777,127995,8203,129778,127999])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(e=t.source||{}).concatemoji?c(e.concatemoji):e.wpemoji&&e.twemoji&&(c(e.twemoji),c(e.wpemoji)))}(window,document,window._wpemojiSettings);
</script>

	
















<link rel='stylesheet' id='oitech-google-fonts-css' href='//fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&#038;family=DM+Sans:wght@400;500;700&#038;display=swap' type='text/css' media='all' />





<script type='text/javascript' src='https://kodesolution.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.1' id='jquery-core-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' id='simple-likes-public-js-js-extra'>
/* <![CDATA[ */
var simpleLikes = {"ajaxurl":"https:\/\/kodesolution.com\/wp-admin\/admin-ajax.php","like":"Like","unlike":"Unlike"};
/* ]]> */
</script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/mascot-core-oitech/external-plugins/wp-post-like-system/js/simple-likes-public.js?ver=0.5' id='simple-likes-public-js-js'></script>
<link rel="https://api.w.org/" href="https://kodesolution.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://kodesolution.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://kodesolution.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 6.1.1" />
<meta name="generator" content="Redux 4.3.20" /><meta name="generator" content="Powered by Slider Revolution 6.6.5 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script>function setREVStartSize(e){
			//window.requestAnimationFrame(function() {
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;
				try {
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) || (e.l=="fullwidth" || e.layout=="fullwidth") ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);
					if(e.layout==="fullscreen" || e.l==="fullscreen")
						newh = Math.max(e.mh,window.RSIH);
					else{
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,
							sl;
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}
					var el = document.getElementById(e.c);
					if (el!==null && el) el.style.height = newh+"px";
					el = document.getElementById(e.c+"_wrapper");
					if (el!==null && el) {
						el.style.height = newh+"px";
						el.style.display = "block";
					}
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}
			//});
		  };</script>
</head>


<body class="error404 menu-full-page tm_elementor_page_status_false tm-stretched-layout container-1230px tm-enable-element-animation-effect elementor-default elementor-kit-9" itemscope itemtype="https://schema.org/WebPage">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-dark-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 0.49803921568627" /><feFuncG type="table" tableValues="0 0.49803921568627" /><feFuncB type="table" tableValues="0 0.49803921568627" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 1" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0 1" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-purple-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.54901960784314 0.98823529411765" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0.71764705882353 0.25490196078431" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-blue-red"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 1" /><feFuncG type="table" tableValues="0 0.27843137254902" /><feFuncB type="table" tableValues="0.5921568627451 0.27843137254902" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-midnight"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 0" /><feFuncG type="table" tableValues="0 0.64705882352941" /><feFuncB type="table" tableValues="0 1" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-magenta-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.78039215686275 1" /><feFuncG type="table" tableValues="0 0.94901960784314" /><feFuncB type="table" tableValues="0.35294117647059 0.47058823529412" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-purple-green"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.65098039215686 0.40392156862745" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0.44705882352941 0.4" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-blue-orange"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.098039215686275 1" /><feFuncG type="table" tableValues="0 0.66274509803922" /><feFuncB type="table" tableValues="0.84705882352941 0.41960784313725" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><div id="wrapper">
		
					<!-- Header -->
		<header id="header" class="header header-layout-type-header-default" >
				<div id="elementor-header-top">
			<div data-elementor-type="wp-post" data-elementor-id="2993" class="elementor elementor-2993">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-3697fac elementor-section-content-middle elementor-hidden-mobile elementor-hidden-tablet elementor-section-full_width elementor-section-stretched elementor-section-height-default elementor-section-height-default" data-id="3697fac" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-4ecda17" data-id="4ecda17" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-0b26e2e elementor-hidden-tablet elementor-hidden-phone elementor-widget elementor-widget-image" data-id="0b26e2e" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
																<a href="https://kodesolution.com/">
							<img decoding="async" width="803" height="237" src="https://kodesolution.com/wp-content/uploads/2022/09/kodesoluton-logo-white.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://kodesolution.com/wp-content/uploads/2022/09/kodesoluton-logo-white.png 803w, https://kodesolution.com/wp-content/uploads/2022/09/kodesoluton-logo-white-300x89.png 300w, https://kodesolution.com/wp-content/uploads/2022/09/kodesoluton-logo-white-768x227.png 768w" sizes="(max-width: 803px) 100vw, 803px" />								</a>
															</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-eba9195" data-id="eba9195" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-c6d8be8 elementor-section-content-middle elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="c6d8be8" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-66 elementor-inner-column elementor-element elementor-element-b18f16f" data-id="b18f16f" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-caf1299 elementor-section-full_width elementor-section-content-middle elementor-section-height-default elementor-section-height-default" data-id="caf1299" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-66 elementor-inner-column elementor-element elementor-element-89fa79b" data-id="89fa79b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-d264534 elementor-widget elementor-widget-tm-ele-header-top-info" data-id="d264534" data-element_type="widget" data-widget_type="tm-ele-header-top-info.default">
				<div class="elementor-widget-container">
					<div class="tm-header-top-info ">
			<ul>
	<li>
	<a 
		 href='mailto:ismailcseku@gmail.com'		>
		<i aria-hidden="true" class="fas fa-envelope"></i>		ismailcseku@gmail.com</a>
</li><li>
	<span 
				>
		<i aria-hidden="true" class="fas fa-map-marker-alt"></i>		58/1, West Bania Khamar Cross Road, Andir Pukur, Khulna</span>
</li>    </ul>
		</div>
			</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-d496026" data-id="d496026" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2240ab2 elementor-widget elementor-widget-tm-ele-navigation-menu" data-id="2240ab2" data-element_type="widget" data-widget_type="tm-ele-navigation-menu.default">
				<div class="elementor-widget-container">
			<div class="tm-sc-simple-nav-menu"><ul id="menu-footer-links" class=""><li id="menu-item-15184" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15184"><a href="https://kodesolution.com/about/">About Company</a></li>
<li id="menu-item-15185" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15185"><a href="https://kodesolution.com/team-grid/">Meet the Team</a></li>
<li id="menu-item-15186" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15186"><a href="https://kodesolution.com/projects-gird/">Our Projects</a></li>
<li id="menu-item-5476" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5476"><a href="https://kodesolution.com/contact-us/">Contact</a></li>
</ul></div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-146790e" data-id="146790e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-bbca5ef elementor-widget elementor-widget-tm-ele-social-links" data-id="bbca5ef" data-element_type="widget" data-widget_type="tm-ele-social-links.default">
				<div class="elementor-widget-container">
			<ul class="tm-sc-social-links flex-end icon-sm links-outlined">

		<li><a class="social-link" href="#" target="_self"><i class="fa fa-twitter"></i></a></li>
			<li><a class="social-link" href="#" target="_self"><i class="fa fa-facebook"></i></a></li>
		
			<li><a class="social-link" href="#" target="_self"><i class="fa fa-instagram"></i></a></li>
			
			<li><a class="social-link" href="#" target="_self"><i class="fa fa-pinterest"></i></a></li>
		</ul>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-d0064d8 elementor-section-content-middle elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="d0064d8" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-ec7bf38" data-id="ec7bf38" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2ec3a62 elementor-widget__width-auto elementor-widget elementor-widget-tm-ele-header-primary-nav" data-id="2ec3a62" data-element_type="widget" data-widget_type="tm-ele-header-primary-nav.default">
				<div class="elementor-widget-container">
			<nav id="top-primary-nav-elementor-id-holder-711406" class="menuzord-primary-nav menuzord">
<ul id="main-nav-id-holder-711406" class="menuzord-menu"><li id="menu-item-13180" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-13180 "><a title="Home" class="menu-item-link" href="https://kodesolution.com/home/"><span>Home</span> </a>
<ul class="dropdown">
	<li id="menu-item-13177" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13177"><a title="Home" class="menu-item-link" href="https://kodesolution.com/home/"><span>Home</span></a>	</li>
	<li id="menu-item-14356" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-14356"><a title="Home Layout2" class="menu-item-link" href="https://kodesolution.com/"><span>Home Layout2</span></a>	</li>
	<li id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="Home Layout3" class="menu-item-link" href="https://kodesolution.com/home-layout3/"><span>Home Layout3</span></a>	</li>
	<li id="menu-item-18916" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18916"><a title="Home Layout4" class="menu-item-link" href="https://kodesolution.com/home-layout4/"><span>Home Layout4</span></a>	</li>
	<li id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18915"><a title="Home Layout5" class="menu-item-link" href="https://kodesolution.com/home-layout5/"><span>Home Layout5</span></a>	</li>
</ul>
</li>
<li id="menu-item-10794" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10794"><a title="About" class="menu-item-link" href="https://kodesolution.com/about/"><span>About</span></a></li>
<li id="menu-item-2999" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2999 "><a title="Pages" class="menu-item-link" href="#"><span>Pages</span> </a>
<ul class="dropdown">
	<li id="menu-item-5491" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5491"><a title="Team Grid" class="menu-item-link" href="https://kodesolution.com/team-grid/"><span>Team Grid</span></a>	</li>
	<li id="menu-item-5496" class="menu-item menu-item-type-post_type menu-item-object-staff-items menu-item-5496"><a title="Team Details" class="menu-item-link" href="https://kodesolution.com/staff/jessica-brown/"><span>Team Details</span></a>	</li>
	<li id="menu-item-5493" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5493"><a title="Projects Gird" class="menu-item-link" href="https://kodesolution.com/projects-gird/"><span>Projects Gird</span></a>	</li>
	<li id="menu-item-5495" class="menu-item menu-item-type-post_type menu-item-object-projects menu-item-5495"><a title="Project Details" class="menu-item-link" href="https://kodesolution.com/projects/smart-visions/"><span>Project Details</span></a>	</li>
	<li id="menu-item-5492" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5492"><a title="Testimonials" class="menu-item-link" href="https://kodesolution.com/testimonials/"><span>Testimonials</span></a>	</li>
	<li id="menu-item-5490" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5490"><a title="FAQ’s" class="menu-item-link" href="https://kodesolution.com/faqs/"><span>FAQ’s</span></a>	</li>
	<li id="menu-item-3000" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3000"><a title="404" class="menu-item-link" href="https://kodesolution.com/2022/oitech/404"><span>404</span></a>	</li>
</ul>
</li>
<li id="menu-item-15313" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-15313 "><a title="Services" class="menu-item-link" href="https://kodesolution.com/services-gird/"><span>Services</span> </a>
<ul class="dropdown">
	<li id="menu-item-15314" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15314"><a title="Services Gird" class="menu-item-link" href="https://kodesolution.com/services-gird/"><span>Services Gird</span></a>	</li>
	<li id="menu-item-15315" class="menu-item menu-item-type-post_type menu-item-object-services menu-item-15315"><a title="Services Details" class="menu-item-link" href="https://kodesolution.com/services/data-visualization/"><span>Services Details</span></a>	</li>
</ul>
</li>
<li id="menu-item-5487" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5487 "><a title="Blog" class="menu-item-link" href="https://kodesolution.com/blog-grid/"><span>Blog</span> </a>
<ul class="dropdown">
	<li id="menu-item-5488" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5488"><a title="Blog Grid" class="menu-item-link" href="https://kodesolution.com/blog-grid/"><span>Blog Grid</span></a>	</li>
	<li id="menu-item-11109" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-11109"><a title="Blog Details" class="menu-item-link" href="https://kodesolution.com/blog/2022/08/31/necessity-may-give-us-best-virtual-court/"><span>Blog Details</span></a>	</li>
</ul>
</li>
<li id="menu-item-5482" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5482"><a title="Contact" class="menu-item-link" href="https://kodesolution.com/contact-us/"><span>Contact</span></a></li>
<li id="menu-item-16282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-16282 "><a title="Shop" class="menu-item-link" href="https://kodesolution.com/shop/"><span>Shop</span> </a>
<ul class="dropdown">
	<li id="menu-item-16283" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16283"><a title="Shop" class="menu-item-link" href="https://kodesolution.com/shop/"><span>Shop</span></a>	</li>
	<li id="menu-item-16287" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16287"><a title="Cart" class="menu-item-link" href="https://kodesolution.com/cart/"><span>Cart</span></a>	</li>
	<li id="menu-item-16288" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16288"><a title="Checkout" class="menu-item-link" href="https://kodesolution.com/checkout/"><span>Checkout</span></a>	</li>
</ul>
</li>
</ul></nav>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5e16873" data-id="5e16873" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-90f6c61 elementor-widget__width-auto elementor-widget-tablet__width-initial elementor-widget-mobile__width-inherit elementor-widget elementor-widget-tm-ele-iconbox" data-id="90f6c61" data-element_type="widget" data-widget_type="tm-ele-iconbox.default">
				<div class="elementor-widget-container">
			<div class="tm-sc-icon-box icon-box icon-left tm-iconbox-icontype-font-icon iconbox-centered-in-responsive-mobile icon-position-icon-left animate-icon-on-hover animate-icon-rotate" >
	
  	<div class="icon-box-wrapper">
		
		<div class="icon-wrapper">
		<a class="icon icon-type-font-icon icon-sm icon-default-bg icon-circled"

						 target="_blank"			href="tel:666-888-6666"
								>
			<i aria-hidden="true" class="fas fa-phone"></i>		</a>

					<div class="icon-bg-img">
				  							</div>
			</div>
			<div class="icon-text">
						<div class="content">Call Anytime </div>
			
				<h6 class="icon-box-title ">
							+88 017 500 500 88					</h6>
								
			
	
					</div>
		<div class="clearfix"></div>
	</div>
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-ed085b8 elementor-widget__width-auto elementor-widget-tablet__width-initial elementor-widget-mobile__width-inherit elementor-widget elementor-widget-tm-ele-button" data-id="ed085b8" data-element_type="widget" data-widget_type="tm-ele-button.default">
				<div class="elementor-widget-container">
			<div class="tm-sc-button btn-view-details ">
	<a  href="https://kodesolution.com/2022/oitech/contact-us/" 
						class="btn btn-theme-colored1 btn-sm btn-flat">

		
		
		<span>
		Get solution		</span>

			</a>
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
							</div>
		</div>
<div id="elementor-header-top-mobile">
			<div data-elementor-type="wp-post" data-elementor-id="2523" class="elementor elementor-2523">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-0af1f1e elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="0af1f1e" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-ad6b4d5" data-id="ad6b4d5" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-443bb1c elementor-widget__width-auto elementor-absolute elementor-widget elementor-widget-image" data-id="443bb1c" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
																<a href="https://kodesolution.com/">
							<img decoding="async" width="803" height="237" src="https://kodesolution.com/wp-content/uploads/2022/09/kodesoluton-logo.png" class="attachment-large size-large" alt="" loading="lazy" srcset="https://kodesolution.com/wp-content/uploads/2022/09/kodesoluton-logo.png 803w, https://kodesolution.com/wp-content/uploads/2022/09/kodesoluton-logo-300x89.png 300w, https://kodesolution.com/wp-content/uploads/2022/09/kodesoluton-logo-768x227.png 768w" sizes="(max-width: 803px) 100vw, 803px" />								</a>
															</div>
				</div>
				<div class="elementor-element elementor-element-0341f3d elementor-widget elementor-widget-tm-ele-header-primary-nav" data-id="0341f3d" data-element_type="widget" data-widget_type="tm-ele-header-primary-nav.default">
				<div class="elementor-widget-container">
			<nav id="top-primary-nav-elementor-id-holder-584288" class="menuzord-primary-nav menuzord">
<ul id="main-nav-id-holder-584288" class="menuzord-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-13180 "><a title="Home" class="menu-item-link" href="https://kodesolution.com/home/"><span>Home</span> </a>
<ul class="dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13177"><a title="Home" class="menu-item-link" href="https://kodesolution.com/home/"><span>Home</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-14356"><a title="Home Layout2" class="menu-item-link" href="https://kodesolution.com/"><span>Home Layout2</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="Home Layout3" class="menu-item-link" href="https://kodesolution.com/home-layout3/"><span>Home Layout3</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18916"><a title="Home Layout4" class="menu-item-link" href="https://kodesolution.com/home-layout4/"><span>Home Layout4</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18915"><a title="Home Layout5" class="menu-item-link" href="https://kodesolution.com/home-layout5/"><span>Home Layout5</span></a>	</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10794"><a title="About" class="menu-item-link" href="https://kodesolution.com/about/"><span>About</span></a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2999 "><a title="Pages" class="menu-item-link" href="#"><span>Pages</span> </a>
<ul class="dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5491"><a title="Team Grid" class="menu-item-link" href="https://kodesolution.com/team-grid/"><span>Team Grid</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-staff-items menu-item-5496"><a title="Team Details" class="menu-item-link" href="https://kodesolution.com/staff/jessica-brown/"><span>Team Details</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5493"><a title="Projects Gird" class="menu-item-link" href="https://kodesolution.com/projects-gird/"><span>Projects Gird</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-projects menu-item-5495"><a title="Project Details" class="menu-item-link" href="https://kodesolution.com/projects/smart-visions/"><span>Project Details</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5492"><a title="Testimonials" class="menu-item-link" href="https://kodesolution.com/testimonials/"><span>Testimonials</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5490"><a title="FAQ’s" class="menu-item-link" href="https://kodesolution.com/faqs/"><span>FAQ’s</span></a>	</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3000"><a title="404" class="menu-item-link" href="https://kodesolution.com/2022/oitech/404"><span>404</span></a>	</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-15313 "><a title="Services" class="menu-item-link" href="https://kodesolution.com/services-gird/"><span>Services</span> </a>
<ul class="dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15314"><a title="Services Gird" class="menu-item-link" href="https://kodesolution.com/services-gird/"><span>Services Gird</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-services menu-item-15315"><a title="Services Details" class="menu-item-link" href="https://kodesolution.com/services/data-visualization/"><span>Services Details</span></a>	</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5487 "><a title="Blog" class="menu-item-link" href="https://kodesolution.com/blog-grid/"><span>Blog</span> </a>
<ul class="dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5488"><a title="Blog Grid" class="menu-item-link" href="https://kodesolution.com/blog-grid/"><span>Blog Grid</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-11109"><a title="Blog Details" class="menu-item-link" href="https://kodesolution.com/blog/2022/08/31/necessity-may-give-us-best-virtual-court/"><span>Blog Details</span></a>	</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5482"><a title="Contact" class="menu-item-link" href="https://kodesolution.com/contact-us/"><span>Contact</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-16282 "><a title="Shop" class="menu-item-link" href="https://kodesolution.com/shop/"><span>Shop</span> </a>
<ul class="dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16283"><a title="Shop" class="menu-item-link" href="https://kodesolution.com/shop/"><span>Shop</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16287"><a title="Cart" class="menu-item-link" href="https://kodesolution.com/cart/"><span>Cart</span></a>	</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16288"><a title="Checkout" class="menu-item-link" href="https://kodesolution.com/checkout/"><span>Checkout</span></a>	</li>
</ul>
</li>
</ul></nav>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
							</div>
		</div>
		

	
			</header>
			
		<div class="top-sliders-container">
		
				
			</div>
		
		<div class="main-content">
		<section class="tm-page-title-elementor">
	<div class="page-title-wrapper">
			<div data-elementor-type="wp-post" data-elementor-id="3484" class="elementor elementor-3484">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-fb4ed9c elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="fb4ed9c" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-extended">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d9c998c" data-id="d9c998c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-1087ebf elementor-widget__width-auto elementor-widget-tablet__width-auto elementor-widget-mobile__width-auto elementor-widget elementor-widget-tm-ele-page-title" data-id="1087ebf" data-element_type="widget" data-widget_type="tm-ele-page-title.default">
				<div class="elementor-widget-container">
			<nav role="navigation" aria-label="Breadcrumbs" class="breadcrumb-trail breadcrumbs-nav"><ul class="breadcrumbs trail-items"><li  class="trail-item trail-begin"><a href="https://kodesolution.com/" rel="home"><span>Home</span></a><i class="tm-breadcrumb-arrow-icon fas fa-arrow-right"></i></li><li  class="trail-item trail-end active"><span><span>404 Not Found</span></span><i class="tm-breadcrumb-arrow-icon fas fa-arrow-right"></i></li></ul></nav>		</div>
				</div>
				<div class="elementor-element elementor-element-3464ea2 elementor-widget elementor-widget-tm-ele-page-title" data-id="3464ea2" data-element_type="widget" data-widget_type="tm-ele-page-title.default">
				<div class="elementor-widget-container">
			
	<h1 class="title" style="">404</h1>

		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
							</div>
			</div>
</section>
<section class="page-404-wrapper page-404-wrapper-padding page-404-layout-simple">
	<div class="display-table">
		<div class="display-table-cell">
			<div class="container">
				<div class="row">
					<div class="col-md-8 offset-md-2">
						<div class="page-404-main-content text-center">

							
							<h1 class="title">404</h1>
							<h3 class="sub-title">Oops! Page Not Found!</h3>
							<div class="content"><p>The page you are looking for does not exist. It might have been moved or deleted.</p>
</div>
							<a class="btn btn-theme-colored1 mt-10 btn-back-to-home" href="https://kodesolution.com/">Back to Home</a>
							
						</div>
						<div class="row mt-30">
							<div class="col-md-6">
															</div>
							<div class="col-md-12 text-center">
															</div>
						</div>
					</div>
				</div>
				<div class="row mt-30">
					<div class="col-md-8 offset-md-2 text-center">
										</div>
				</div>
			</div>
		</div>
	</div>
</section>

	

		</div>
	<!-- main-content end --> 
	

			<!-- Footer -->
		<footer id="footer" class="footer ">
			<div class="footer-widget-area">
			<div class="container">
								<div class="row">
					<div class="col-md-12">
											<!-- the loop -->
															<div data-elementor-type="wp-post" data-elementor-id="693" class="elementor elementor-693">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-6c30181 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="6c30181" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-extended">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7c9b0bd" data-id="7c9b0bd" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-e12527e elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="e12527e" data-element_type="section">
						<div class="elementor-container elementor-column-gap-extended">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-87e6883" data-id="87e6883" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-1a817ef elementor-widget elementor-widget-image" data-id="1a817ef" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img decoding="async" width="803" height="237" src="https://kodesolution.com/wp-content/uploads/2022/09/kodesoluton-logo-white.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://kodesolution.com/wp-content/uploads/2022/09/kodesoluton-logo-white.png 803w, https://kodesolution.com/wp-content/uploads/2022/09/kodesoluton-logo-white-300x89.png 300w, https://kodesolution.com/wp-content/uploads/2022/09/kodesoluton-logo-white-768x227.png 768w" sizes="(max-width: 803px) 100vw, 803px" />															</div>
				</div>
				<div class="elementor-element elementor-element-2547c17 elementor-widget elementor-widget-tm-ele-text-editor" data-id="2547c17" data-element_type="widget" data-widget_type="tm-ele-text-editor.default">
				<div class="elementor-widget-container">
					<div class="tm-text-editor">
		Desires to obtain pain of itself, because it is pain, but occasionally circumstances.		</div>
			</div>
				</div>
				<div class="elementor-element elementor-element-f2359b9 elementor-widget elementor-widget-tm-ele-social-links" data-id="f2359b9" data-element_type="widget" data-widget_type="tm-ele-social-links.default">
				<div class="elementor-widget-container">
			<ul class="tm-sc-social-links icon-circled icon-md icon-dark">

			<li><a class="social-link" href="https://www.facebook.com/kodesolution" target="_self"><i class="fa fa-facebook"></i></a></li>
		
				
			</ul>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-41ccdba" data-id="41ccdba" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-e9c2099 elementor-widget elementor-widget-tm-ele-text-editor" data-id="e9c2099" data-element_type="widget" data-widget_type="tm-ele-text-editor.default">
				<div class="elementor-widget-container">
					<div class="tm-text-editor">
		<h4>Explore</h4>		</div>
			</div>
				</div>
				<div class="elementor-element elementor-element-37e6509 elementor-widget elementor-widget-spacer" data-id="37e6509" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-97cb0e7 elementor-widget elementor-widget-tm-ele-navigation-menu" data-id="97cb0e7" data-element_type="widget" data-widget_type="tm-ele-navigation-menu.default">
				<div class="elementor-widget-container">
			<div class="tm-sc-simple-nav-menu"><ul id="menu-footer-links-1" class=""><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15184"><a href="https://kodesolution.com/about/">About Company</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15185"><a href="https://kodesolution.com/team-grid/">Meet the Team</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15186"><a href="https://kodesolution.com/projects-gird/">Our Projects</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5476"><a href="https://kodesolution.com/contact-us/">Contact</a></li>
</ul></div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-ccae7b6" data-id="ccae7b6" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2002baf elementor-widget elementor-widget-tm-ele-text-editor" data-id="2002baf" data-element_type="widget" data-widget_type="tm-ele-text-editor.default">
				<div class="elementor-widget-container">
					<div class="tm-text-editor">
		<h4>Contact</h4>		</div>
			</div>
				</div>
				<div class="elementor-element elementor-element-397d895 elementor-widget elementor-widget-spacer" data-id="397d895" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-fadbf22 elementor-widget elementor-widget-tm-ele-text-editor" data-id="fadbf22" data-element_type="widget" data-widget_type="tm-ele-text-editor.default">
				<div class="elementor-widget-container">
					<div class="tm-text-editor">
		<p><span>58/1, West Bania Khamar Cross Road, Andir Pukur, Khulna</span></p>		</div>
			</div>
				</div>
				<div class="elementor-element elementor-element-fae71e4 elementor-widget elementor-widget-tm-ele-contact-list" data-id="fae71e4" data-element_type="widget" data-widget_type="tm-ele-contact-list.default">
				<div class="elementor-widget-container">
					<div class="tm-contact-list  contact-list-flat">
			<ul>
	<li class="clearfix">
	<div class="icon"><i aria-hidden="true" class="fas fa-envelope"></i></div>
		<div class="text">
		<div 
				>
		ismailcseku@gmail.com		</div>
	</div>
</li><li class="clearfix">
	<div class="icon"><i aria-hidden="true" class="fas fa-phone-square"></i></div>
		<div class="text">
		<a 
		 href='tel:+8801750050088'		>
		+88 017 500 500 88		</a>
	</div>
</li>    </ul>
		</div>
			</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-4eccc3d" data-id="4eccc3d" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-cc6a77b elementor-widget elementor-widget-tm-ele-text-editor" data-id="cc6a77b" data-element_type="widget" data-widget_type="tm-ele-text-editor.default">
				<div class="elementor-widget-container">
					<div class="tm-text-editor">
		<h4>Gallery</h4>		</div>
			</div>
				</div>
				<div class="elementor-element elementor-element-f441683 elementor-widget elementor-widget-spacer" data-id="f441683" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-07a4cd2 elementor-widget elementor-widget-shortcode" data-id="07a4cd2" data-element_type="widget" data-widget_type="shortcode.default">
				<div class="elementor-widget-container">
					<div class="elementor-shortcode">[instagram-feed feed=1]</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-5c48fd6 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="5c48fd6" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-91212dd" data-id="91212dd" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-4054721 elementor-widget elementor-widget-tm-ele-text-editor-advanced" data-id="4054721" data-element_type="widget" data-widget_type="tm-ele-text-editor-advanced.default">
				<div class="elementor-widget-container">
					<div class="tm-text-editor-advanced">
					<div class="each-item elementor-repeater-item-ad20a2e">
				<p>© Copyright 2023 by kodesolution.com</p>				</div>
						</div>
			</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
							</div>
														<!-- end of the loop -->
																</div>
				</div>
							</div>
		</div>
		</footer>
			
	</div>
<!-- wrapper end -->

		<script>
			window.RS_MODULES = window.RS_MODULES || {};
			window.RS_MODULES.modules = window.RS_MODULES.modules || {};
			window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
			window.RS_MODULES.defered = true;
			window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
			window.RS_MODULES.type = 'compiled';
		</script>
					<a class="scroll-to-top" href="#"><i class="fa fa-angle-up"></i></a>
			<script type="text/javascript">
		jQuery( function($) {
			if ( typeof wc_add_to_cart_params === 'undefined' )
				return false;

			$(document.body).on( 'added_to_cart', function( event, fragments, cart_hash, $button ) {
				var $pid = $button.data('product_id');

				$.ajax({
					type: 'POST',
					url: wc_add_to_cart_params.ajax_url,
					data: {
						'action': 'wc_item_added_signal',
						'_wpnonce': '2b0e7eef75',
						'id'    : $pid
					},
					success: function (response) {
						$('.tm-floating-woocart-wrapper').addClass('open');
					}
				});
			});
		});
	</script>
	






<style id='elementor-frontend-inline-css' type='text/css'>
.elementor-2993 .elementor-element.elementor-element-3697fac > .elementor-container > .elementor-column > .elementor-widget-wrap{align-content:center;align-items:center;}.elementor-2993 .elementor-element.elementor-element-3697fac{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;padding:0px 0px 0px 0px;}.elementor-2993 .elementor-element.elementor-element-3697fac > .elementor-background-overlay{transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-bc-flex-widget .elementor-2993 .elementor-element.elementor-element-4ecda17.elementor-column .elementor-widget-wrap{align-items:center;}.elementor-2993 .elementor-element.elementor-element-4ecda17.elementor-column.elementor-element[data-element_type="column"] > .elementor-widget-wrap.elementor-element-populated{align-content:center;align-items:center;}.elementor-2993 .elementor-element.elementor-element-4ecda17:not(.elementor-motion-effects-element-type-background) > .elementor-widget-wrap, .elementor-2993 .elementor-element.elementor-element-4ecda17 > .elementor-widget-wrap > .elementor-motion-effects-container > .elementor-motion-effects-layer{background-color:#222429;}.elementor-2993 .elementor-element.elementor-element-4ecda17 > .elementor-element-populated{border-style:solid;border-width:0px 10px 0px 0px;border-color:#FFAA17;transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;padding:0px 0px 0px 0px;}.elementor-2993 .elementor-element.elementor-element-4ecda17 > .elementor-element-populated > .elementor-background-overlay{transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-2993 .elementor-element.elementor-element-0b26e2e{text-align:center;}.elementor-2993 .elementor-element.elementor-element-0b26e2e img{width:151px;}.elementor-2993 .elementor-element.elementor-element-eba9195:not(.elementor-motion-effects-element-type-background) > .elementor-widget-wrap, .elementor-2993 .elementor-element.elementor-element-eba9195 > .elementor-widget-wrap > .elementor-motion-effects-container > .elementor-motion-effects-layer{background-color:#FFFFFF;}.elementor-2993 .elementor-element.elementor-element-eba9195 > .elementor-element-populated{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;padding:0px 40px 0px 0px;}.elementor-2993 .elementor-element.elementor-element-eba9195 > .elementor-element-populated > .elementor-background-overlay{transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-2993 .elementor-element.elementor-element-c6d8be8 > .elementor-container > .elementor-column > .elementor-widget-wrap{align-content:center;align-items:center;}.elementor-2993 .elementor-element.elementor-element-c6d8be8, .elementor-2993 .elementor-element.elementor-element-c6d8be8 > .elementor-background-overlay{border-radius:0px 0px 0px 0px;}.elementor-2993 .elementor-element.elementor-element-c6d8be8{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;padding:0px 0px 0px 30px;}.elementor-2993 .elementor-element.elementor-element-c6d8be8 > .elementor-background-overlay{transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-2993 .elementor-element.elementor-element-b18f16f:not(.elementor-motion-effects-element-type-background) > .elementor-widget-wrap, .elementor-2993 .elementor-element.elementor-element-b18f16f > .elementor-widget-wrap > .elementor-motion-effects-container > .elementor-motion-effects-layer{background-color:#F4F5F8;}.elementor-2993 .elementor-element.elementor-element-b18f16f > .elementor-element-populated{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2993 .elementor-element.elementor-element-b18f16f > .elementor-element-populated > .elementor-background-overlay{transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-2993 .elementor-element.elementor-element-caf1299 > .elementor-container > .elementor-column > .elementor-widget-wrap{align-content:center;align-items:center;}.elementor-2993 .elementor-element.elementor-element-caf1299{padding:0px 40px 0px 40px;}.elementor-2993 .elementor-element.elementor-element-d264534 .tm-header-top-info li i{display:inline-block;color:var(--theme-color1);}.elementor-2993 .elementor-element.elementor-element-d264534 .tm-header-top-info li .prefix{display:inline-block;}.elementor-2993 .elementor-element.elementor-element-d264534 .tm-header-top-info li a:hover{color:#808287;}.elementor-2993 .elementor-element.elementor-element-d264534 .tm-header-top-info li > *{font-size:13px;font-weight:400;color:#808287;}.elementor-2993 .elementor-element.elementor-element-d264534{text-align:left;}.elementor-2993 .elementor-element.elementor-element-2240ab2 .tm-sc-simple-nav-menu ul li{display:inline-block;}.elementor-2993 .elementor-element.elementor-element-2240ab2 .tm-sc-simple-nav-menu ul{text-align:right;}.elementor-2993 .elementor-element.elementor-element-2240ab2 .tm-sc-simple-nav-menu li, .elementor-2993 .elementor-element.elementor-element-2240ab2 .tm-sc-simple-nav-menu li a{font-size:13px;font-weight:400;}.elementor-2993 .elementor-element.elementor-element-2240ab2 .tm-sc-simple-nav-menu li{color:#808287;}.elementor-2993 .elementor-element.elementor-element-2240ab2 .tm-sc-simple-nav-menu li a{color:#808287;padding:0px 2px 0px 2px;}.elementor-2993 .elementor-element.elementor-element-2240ab2 .tm-sc-simple-nav-menu li a:hover{color:var(--theme-color2);}.elementor-2993 .elementor-element.elementor-element-2240ab2 .tm-sc-simple-nav-menu li.current-menu-item a{color:var(--theme-color2);}.elementor-2993 .elementor-element.elementor-element-146790e.elementor-column > .elementor-widget-wrap{justify-content:flex-end;}.elementor-2993 .elementor-element.elementor-element-bbca5ef .tm-sc-social-links{justify-content:flex-end;}.elementor-2993 .elementor-element.elementor-element-bbca5ef .social-link{color:#222429;background-color:#02010100;}.elementor-2993 .elementor-element.elementor-element-bbca5ef .social-link:hover{color:var(--theme-color1) !important;}.elementor-2993 .elementor-element.elementor-element-d0064d8 > .elementor-container > .elementor-column > .elementor-widget-wrap{align-content:center;align-items:center;}.elementor-2993 .elementor-element.elementor-element-d0064d8{padding:0px 15px 0px 0px;}.elementor-2993 .elementor-element.elementor-element-ec7bf38 > .elementor-element-populated{margin:0px 0px 0px 45px;--e-column-margin-right:0px;--e-column-margin-left:45px;}.elementor-2993 .elementor-element.elementor-element-2ec3a62 .menuzord-menu > li.menu-item > a{font-family:"DM Sans", Sans-serif;font-size:16px;font-weight:500;line-height:30px;color:#767676;}.elementor-2993 .elementor-element.elementor-element-2ec3a62 .menuzord-menu > li.menu-item:hover > a, .elementor-2993 .elementor-element.elementor-element-2ec3a62 .menuzord-menu > li.menu-item.active  > a{color:var(--theme-color2);}@media (min-width: 1025px){ .elementor-2993 .elementor-element.elementor-element-2ec3a62 .menuzord-menu > li.menu-item{padding:25px 0px 25px 0px};margin:0px 0px 0px 0px};}@media (min-width: 1025px){ header#header .elementor-2993 .elementor-element.elementor-element-2ec3a62 .menuzord-menu > li.menu-item{padding:25px 0px 25px 0px};margin:0px 0px 0px 0px};}@media (min-width: 1025px){ .elementor-2993 .elementor-element.elementor-element-2ec3a62 .menuzord-menu > li.menu-item > a{padding:0px 5px 0px 25px};}@media (min-width: 1025px){ header#header .elementor-2993 .elementor-element.elementor-element-2ec3a62 .menuzord-menu > li.menu-item > a{padding:0px 5px 0px 25px};}.elementor-2993 .elementor-element.elementor-element-2ec3a62{width:auto;max-width:auto;}.elementor-bc-flex-widget .elementor-2993 .elementor-element.elementor-element-5e16873.elementor-column .elementor-widget-wrap{align-items:center;}.elementor-2993 .elementor-element.elementor-element-5e16873.elementor-column.elementor-element[data-element_type="column"] > .elementor-widget-wrap.elementor-element-populated{align-content:center;align-items:center;}.elementor-2993 .elementor-element.elementor-element-5e16873.elementor-column > .elementor-widget-wrap{justify-content:flex-end;}.elementor-2993 .elementor-element.elementor-element-5e16873 > .elementor-element-populated{margin:0px 0px 0px 0px;--e-column-margin-right:0px;--e-column-margin-left:0px;}.elementor-2993 .elementor-element.elementor-element-90f6c61 .icon-wrapper{display:flex;justify-content:center;}.elementor-2993 .elementor-element.elementor-element-90f6c61 .icon{display:flex;justify-content:center;align-items:center;margin:0px 15px 0px 0px;background-color:#222429;width:42px;height:42px;}.elementor-2993 .elementor-element.elementor-element-90f6c61 .icon i{line-height:1;color:#FFFFFF;}.elementor-2993 .elementor-element.elementor-element-90f6c61 .icon svg{line-height:1;fill:#FFFFFF;}.elementor-2993 .elementor-element.elementor-element-90f6c61 .icon i, .elementor-2993 .elementor-element.elementor-element-90f6c61 .icon svg{font-size:1rem;}.elementor-2993 .elementor-element.elementor-element-90f6c61 .icon-wrapper .icon-bg-img{left:0%;top:0%;}.elementor-2993 .elementor-element.elementor-element-90f6c61:hover .icon-wrapper .icon-bg-img{left:0%;top:0%;}.elementor-2993 .elementor-element.elementor-element-90f6c61 .icon-box-title, .elementor-2993 .elementor-element.elementor-element-90f6c61 .icon-box-title a{font-size:14px;}.elementor-2993 .elementor-element.elementor-element-90f6c61 .icon-box-title{margin:0px 0px 0px 0px;}.elementor-2993 .elementor-element.elementor-element-90f6c61 .content, .elementor-2993 .elementor-element.elementor-element-90f6c61 .content *{font-size:12px;}.elementor-2993 .elementor-element.elementor-element-90f6c61 > .elementor-widget-container{margin:0px 20px 0px 20px;}.elementor-2993 .elementor-element.elementor-element-90f6c61{width:auto;max-width:auto;}.elementor-2993 .elementor-element.elementor-element-ed085b8 .btn-view-details{text-align:right;}.elementor-2993 .elementor-element.elementor-element-ed085b8 .btn{padding:12px 40px 12px 40px;}.elementor-2993 .elementor-element.elementor-element-ed085b8{width:auto;max-width:auto;}@media(max-width:1024px){.elementor-2993 .elementor-element.elementor-element-d264534{text-align:center;}.elementor-2993 .elementor-element.elementor-element-bbca5ef .tm-sc-social-links{justify-content:center;}.elementor-2993 .elementor-element.elementor-element-90f6c61 > .elementor-widget-container{margin:0px 0px 0px 0px;padding:0px 0px 0px 0px;}.elementor-2993 .elementor-element.elementor-element-90f6c61{width:33%;max-width:33%;}.elementor-2993 .elementor-element.elementor-element-ed085b8 .btn-view-details{text-align:Center;}.elementor-2993 .elementor-element.elementor-element-ed085b8{width:26%;max-width:26%;}}@media(max-width:767px){.elementor-2993 .elementor-element.elementor-element-90f6c61 > .elementor-widget-container{margin:0px 0px 30px 0px;padding:0px 0px 0px 0px;}.elementor-2993 .elementor-element.elementor-element-90f6c61{width:100%;max-width:100%;}.elementor-2993 .elementor-element.elementor-element-ed085b8 .btn-view-details{text-align:Center;}.elementor-2993 .elementor-element.elementor-element-ed085b8{width:100%;max-width:100%;}}@media(min-width:768px){.elementor-2993 .elementor-element.elementor-element-4ecda17{width:13.46%;}.elementor-2993 .elementor-element.elementor-element-eba9195{width:86.54%;}.elementor-2993 .elementor-element.elementor-element-b18f16f{width:85.264%;}.elementor-2993 .elementor-element.elementor-element-146790e{width:14.014%;}.elementor-2993 .elementor-element.elementor-element-ec7bf38{width:52.794%;}.elementor-2993 .elementor-element.elementor-element-5e16873{width:47.161%;}}@media(max-width:1024px) and (min-width:768px){.elementor-2993 .elementor-element.elementor-element-5e16873{width:100%;}}
.elementor-2523 .elementor-element.elementor-element-0af1f1e{border-style:solid;border-width:0px 0px 1px 0px;border-color:#BCBCBC21;transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;padding:0px 0px 0px 0px;}.elementor-2523 .elementor-element.elementor-element-0af1f1e > .elementor-background-overlay{transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-2523 .elementor-element.elementor-element-443bb1c{text-align:left;width:auto;max-width:auto;top:13px;}.elementor-2523 .elementor-element.elementor-element-443bb1c img{width:115px;}body:not(.rtl) .elementor-2523 .elementor-element.elementor-element-443bb1c{left:10px;}body.rtl .elementor-2523 .elementor-element.elementor-element-443bb1c{right:10px;}
.elementor-3484 .elementor-element.elementor-element-fb4ed9c:not(.elementor-motion-effects-element-type-background), .elementor-3484 .elementor-element.elementor-element-fb4ed9c > .elementor-motion-effects-container > .elementor-motion-effects-layer{background-image:url("https://kodesolution.com/2022/oitech/wp-content/uploads/2022/10/page-title.jpg");background-position:center center;background-repeat:no-repeat;background-size:cover;}.elementor-3484 .elementor-element.elementor-element-fb4ed9c{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;padding:145px 0px 125px 0px;}.elementor-3484 .elementor-element.elementor-element-fb4ed9c > .elementor-background-overlay{transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-3484 .elementor-element.elementor-element-fb4ed9c > .elementor-container{text-align:center;}.elementor-3484 .elementor-element.elementor-element-d9c998c.elementor-column > .elementor-widget-wrap{justify-content:center;}.elementor-3484 .elementor-element.elementor-element-d9c998c > .elementor-element-populated{text-align:left;}.elementor-3484 .elementor-element.elementor-element-1087ebf{text-align:center;width:auto;max-width:auto;align-self:center;}.elementor-3484 .elementor-element.elementor-element-1087ebf .breadcrumbs{font-size:12px;font-weight:500;text-transform:uppercase;letter-spacing:1px;display:inline-block;background-color:#FFFFFF21;padding:10px 30px 10px 30px;}.elementor-3484 .elementor-element.elementor-element-1087ebf .breadcrumbs .trail-item:not(.trail-end){color:#FFFFFF;}.elementor-3484 .elementor-element.elementor-element-1087ebf .breadcrumbs a:not(.btn){color:#FFFFFF;}.elementor-3484 .elementor-element.elementor-element-1087ebf .breadcrumbs .trail-item:not(.trail-end):hover{color:var(--theme-color1);}.elementor-3484 .elementor-element.elementor-element-1087ebf .breadcrumbs a:not(.btn):hover{color:var(--theme-color1);}.elementor-3484 .elementor-element.elementor-element-1087ebf .breadcrumbs li:last-child{color:#F2F2F2;}.elementor-3484 .elementor-element.elementor-element-1087ebf .breadcrumbs li:last-child a{color:#F2F2F2;}.elementor-3484 .elementor-element.elementor-element-1087ebf .breadcrumbs li .tm-breadcrumb-arrow-icon{font-size:12px;color:#FFFFFF;}.elementor-3484 .elementor-element.elementor-element-3464ea2{text-align:center;}.elementor-3484 .elementor-element.elementor-element-3464ea2 .title{color:#FFFFFF;margin:0px 0px 0px 0px;}@media(max-width:1024px){.elementor-3484 .elementor-element.elementor-element-fb4ed9c{padding:105px 0px 90px 0px;}.elementor-3484 .elementor-element.elementor-element-1087ebf{width:auto;max-width:auto;}}@media(max-width:767px){.elementor-3484 .elementor-element.elementor-element-1087ebf{width:auto;max-width:auto;}}
.elementor-693 .elementor-element.elementor-element-6c30181:not(.elementor-motion-effects-element-type-background), .elementor-693 .elementor-element.elementor-element-6c30181 > .elementor-motion-effects-container > .elementor-motion-effects-layer{background-image:url("https://kodesolution.com/2022/oitech/wp-content/uploads/2022/08/footer_bg.jpg");background-position:top left;background-repeat:no-repeat;background-size:cover;}.elementor-693 .elementor-element.elementor-element-6c30181 > .elementor-background-overlay{background-color:#222429;opacity:0.92;transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-693 .elementor-element.elementor-element-6c30181{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;padding:0px 0px 0px 0px;}.elementor-693 .elementor-element.elementor-element-e12527e{padding:85px 0px 90px 0px;}.elementor-693 .elementor-element.elementor-element-1a817ef{text-align:left;}.elementor-693 .elementor-element.elementor-element-1a817ef img{width:210px;}.elementor-693 .elementor-element.elementor-element-1a817ef > .elementor-widget-container{padding:5px 0px 5px 0px;}.elementor-693 .elementor-element.elementor-element-2547c17 .tm-text-editor, .elementor-693 .elementor-element.elementor-element-2547c17 .tm-text-editor *{font-size:16px;font-weight:400;line-height:30px;}.elementor-693 .elementor-element.elementor-element-2547c17 .tm-text-editor{color:#CCCCCC;}.elementor-693 .elementor-element.elementor-element-2547c17 .tm-text-editor *{color:#CCCCCC;}.elementor-693 .elementor-element.elementor-element-f2359b9 .social-link{color:#FFFFFF;background-color:#2C2E33;}.elementor-693 .elementor-element.elementor-element-f2359b9 .social-link:hover{color:var(--theme-color2) !important;background-color:var(--theme-color1) !important;}.elementor-693 .elementor-element.elementor-element-e9c2099 .tm-text-editor, .elementor-693 .elementor-element.elementor-element-e9c2099 .tm-text-editor *{font-size:20px;}.elementor-693 .elementor-element.elementor-element-e9c2099 .tm-text-editor{margin:0px 0px 0px 0px;color:#FFFFFF;}.elementor-693 .elementor-element.elementor-element-e9c2099 .tm-text-editor *{margin:0px 0px 0px 0px;color:#FFFFFF;}.elementor-693 .elementor-element.elementor-element-37e6509{--spacer-size:2px;}.elementor-693 .elementor-element.elementor-element-37e6509 > .elementor-widget-container{background-color:transparent;background-image:linear-gradient(90deg, #FFAA17 8%, #FFFFFF17 8%);}.elementor-693 .elementor-element.elementor-element-97cb0e7 .tm-sc-simple-nav-menu li .tm-nav-arrow-icon{display:none;color:var(--theme-color1);left:0px;}.elementor-693 .elementor-element.elementor-element-97cb0e7 .tm-sc-simple-nav-menu li:hover .tm-nav-arrow-icon{color:var(--theme-color3);}.elementor-693 .elementor-element.elementor-element-97cb0e7 .tm-sc-simple-nav-menu li{color:#CCCCCC;}.elementor-693 .elementor-element.elementor-element-97cb0e7 .tm-sc-simple-nav-menu li a{color:#CCCCCC;padding:0px 0px 0px 0px;}.elementor-693 .elementor-element.elementor-element-97cb0e7 .tm-sc-simple-nav-menu li a:hover{color:#FFFFFF;}.elementor-693 .elementor-element.elementor-element-2002baf .tm-text-editor, .elementor-693 .elementor-element.elementor-element-2002baf .tm-text-editor *{font-size:20px;}.elementor-693 .elementor-element.elementor-element-2002baf .tm-text-editor{margin:0px 0px 0px 0px;color:#FFFFFF;}.elementor-693 .elementor-element.elementor-element-2002baf .tm-text-editor *{margin:0px 0px 0px 0px;color:#FFFFFF;}.elementor-693 .elementor-element.elementor-element-397d895{--spacer-size:2px;}.elementor-693 .elementor-element.elementor-element-397d895 > .elementor-widget-container{background-color:transparent;background-image:linear-gradient(90deg, #FFAA17 8%, #FFFFFF17 8%);}.elementor-693 .elementor-element.elementor-element-fadbf22 .tm-text-editor{margin:0px 0px 5px 0px;color:#CCCCCC;}.elementor-693 .elementor-element.elementor-element-fadbf22 .tm-text-editor *{margin:0px 0px 5px 0px;color:#CCCCCC;}.elementor-693 .elementor-element.elementor-element-fae71e4 .tm-contact-list li{display:flex;}.elementor-693 .elementor-element.elementor-element-fae71e4 .tm-contact-list li > *{display:flex;color:#FFFFFF;}.elementor-693 .elementor-element.elementor-element-fae71e4 .tm-contact-list li .icon{color:var(--theme-color1);}.elementor-693 .elementor-element.elementor-element-fae71e4 .tm-contact-list li .icon svg{fill:var(--theme-color1);}.elementor-693 .elementor-element.elementor-element-fae71e4 .tm-contact-list li:hover .icon{color:var(--theme-color3);}.elementor-693 .elementor-element.elementor-element-fae71e4 .tm-contact-list li:hover .icon svg{fill:var(--theme-color3);}.elementor-693 .elementor-element.elementor-element-fae71e4 .tm-contact-list li a{color:#FFFFFF;}.elementor-693 .elementor-element.elementor-element-fae71e4{text-align:left;}.elementor-693 .elementor-element.elementor-element-cc6a77b .tm-text-editor, .elementor-693 .elementor-element.elementor-element-cc6a77b .tm-text-editor *{font-size:20px;}.elementor-693 .elementor-element.elementor-element-cc6a77b .tm-text-editor{margin-top:0;color:#FFFFFF;}.elementor-693 .elementor-element.elementor-element-cc6a77b .tm-text-editor *{margin-top:0;color:#FFFFFF;}.elementor-693 .elementor-element.elementor-element-f441683{--spacer-size:2px;}.elementor-693 .elementor-element.elementor-element-f441683 > .elementor-widget-container{background-color:transparent;background-image:linear-gradient(90deg, #FFAA17 8%, #FFFFFF17 8%);}.elementor-693 .elementor-element.elementor-element-5c48fd6 > .elementor-container > .elementor-column > .elementor-widget-wrap{align-content:center;align-items:center;}.elementor-693 .elementor-element.elementor-element-5c48fd6:not(.elementor-motion-effects-element-type-background), .elementor-693 .elementor-element.elementor-element-5c48fd6 > .elementor-motion-effects-container > .elementor-motion-effects-layer{background-color:#2C2E33;}.elementor-693 .elementor-element.elementor-element-5c48fd6{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;margin-top:0px;margin-bottom:-15px;padding:25px 0px 25px 0px;}.elementor-693 .elementor-element.elementor-element-5c48fd6 > .elementor-background-overlay{transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-693 .elementor-element.elementor-element-4054721 .elementor-repeater-item-ad20a2e{text-align:center;color:#8C8F94;}.elementor-693 .elementor-element.elementor-element-4054721 .elementor-repeater-item-ad20a2e *{color:#8C8F94;}
.elementor-kit-9{--e-global-color-primary:#6EC1E4;--e-global-color-secondary:#54595F;--e-global-color-text:#7A7A7A;--e-global-color-accent:#61CE70;--e-global-typography-primary-font-family:"Roboto";--e-global-typography-primary-font-weight:600;--e-global-typography-secondary-font-family:"Roboto Slab";--e-global-typography-secondary-font-weight:400;--e-global-typography-text-font-family:"Roboto";--e-global-typography-text-font-weight:400;--e-global-typography-accent-font-family:"Roboto";--e-global-typography-accent-font-weight:500;}.elementor-section.elementor-section-boxed > .elementor-container{max-width:1140px;}.e-con{--container-max-width:1140px;}.elementor-widget:not(:last-child){margin-bottom:20px;}.elementor-element{--widgets-spacing:20px;}{}h1.entry-title{display:var(--page-title-display);}@media(max-width:1024px){.elementor-section.elementor-section-boxed > .elementor-container{max-width:1024px;}.e-con{--container-max-width:1024px;}}@media(max-width:767px){.elementor-section.elementor-section-boxed > .elementor-container{max-width:767px;}.e-con{--container-max-width:767px;}}
</style>


<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=DM+Sans%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=swap&#038;ver=6.1.1' type='text/css' media='all' />





<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/mascot-core-oitech/assets/js/ion.rangeSlider/js/ion.rangeSlider.min.js?ver=6.1.1' id='mascot-core-rangeSlider-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.6.4' id='swv-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/kodesolution.com\/wp-json\/","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.6.4' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.6.5' defer async id='tp-tools-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.6.5' defer async id='revmin-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/mascot-core/assets/js/plugins/owl-carousel/owl.carousel.min.js?ver=6.1.1' id='owl-carousel-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/mascot-core/assets/js/plugins/owl-carousel/jquery.owl-filter.js?ver=6.1.1' id='jquery-owl-filter-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/mascot-core/assets/js/plugins/owl.carousel2.thumbs.min.js?ver=6.1.1' id='owl-carousel2-thumbs-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/mascot-core/assets/js/plugins/jquery.animatenumbers.min.js?ver=6.1.1' id='jquery-animatenumbers-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/mascot-core/assets/js/plugins/jquery.easypiechart.min.js?ver=6.1.1' id='jquery-easypiechart-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/mascot-core/assets/js/plugins/jquery.tilt.min.js?ver=6.1.1' id='jquery-tilt-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-includes/js/jquery/ui/tabs.min.js?ver=1.13.2' id='jquery-ui-tabs-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-includes/js/jquery/ui/accordion.min.js?ver=1.13.2' id='jquery-ui-accordion-js'></script>
<script type='text/javascript' id='mediaelement-core-js-before'>
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
</script>
<script type='text/javascript' src='https://kodesolution.com/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.17' id='mediaelement-core-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=6.1.1' id='mediaelement-migrate-js'></script>
<script type='text/javascript' id='mediaelement-js-extra'>
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */
</script>
<script type='text/javascript' src='https://kodesolution.com/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=6.1.1' id='wp-mediaelement-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/popper.min.js?ver=6.1.1' id='popper-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/bootstrap.min.js?ver=6.1.1' id='bootstrap-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/menuzord/js/menuzord.js?ver=6.1.1' id='menuzord-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/jquery.appear.js?ver=6.1.1' id='jquery-appear-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/isotope.pkgd.min.js?ver=6.1.1' id='isotope-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/jquery-scrolltofixed-min.js?ver=6.1.1' id='jquery-scrolltofixed-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/jquery.easing.min.js?ver=6.1.1' id='jquery-easing-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/jquery.fitvids.js?ver=6.1.1' id='jquery-fitvids-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/jquery.localscroll.min.js?ver=6.1.1' id='jquery-localscroll-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/jquery.scrollto.min.js?ver=6.1.1' id='jquery-scrollto-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/jquery.paroller.min.js?ver=6.1.1' id='jquery-paroller-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/jquery.lettering.js?ver=6.1.1' id='jquery-lettering-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/jquery.textillate.js?ver=6.1.1' id='jquery-textillate-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/jquery-nice-select/jquery.nice-select.min.js?ver=6.1.1' id='jquery-nice-select-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/plugins/wow.min.js?ver=6.1.1' id='wow-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/themes/oitech/assets/js/custom.js?ver=6.1.1' id='mascot-custom-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/mascot-core/assets/js/plugins/magnific-popup/jquery.magnific-popup.min.js?ver=6.1.1' id='magnific-popup-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/mascot-core/assets/js/plugins/vivus.min.js?ver=6.1.1' id='vivus-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/mascot-core/assets/js/plugins/jquery.countto.js?ver=6.1.1' id='jquery-countto-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/mascot-core-oitech/assets/js/elementor-mascot.js?ver=6.1.1' id='mascot-core-hellojs-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=3.8.1' id='font-awesome-4-shim-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.8.1' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.8.1' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Extra","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Extra","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.8.1","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"a11y_improvements":true,"additional_custom_breakpoints":true,"e_import_export":true,"e_hidden_wordpress_widgets":true,"landing-pages":true,"elements-color-picker":true,"favorite-widgets":true,"admin-top-bar":true},"urls":{"assets":"https:\/\/kodesolution.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":0,"title":"Page not found &#8211; KodeSolution Dot Net","excerpt":""}};
</script>
<script type='text/javascript' src='https://kodesolution.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.8.1' id='elementor-frontend-js'></script>
</body>
</html>

<!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/

Page Caching using disk: enhanced (Page is 404) 

Served from: kodesolution.com @ 2023-02-08 09:01:24 by W3 Total Cache
-->