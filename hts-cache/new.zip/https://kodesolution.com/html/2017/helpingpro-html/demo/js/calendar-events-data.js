var calendarEvents= [
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2017-05-01'
    },
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2017-05-03'
    },
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2017-05-15',
        end: '2017-05-16'
    },
    {
        id: 999,
        title: 'Repeating Event',
        url: 'http://google.com/',
        start: '2017-05-26T16:00:00',
        start: '2017-05-27'
    },
    {
        id: 999,
        title: 'Repeating Event',
        url: 'http://google.com/',
        start: '2017-05-26T16:00:00'
    },
    {
        title: 'Conference',
        start: '2017-05-11',
        end: '2017-05-13'
    },
    {
        title: 'Meeting',
        start: '2017-05-12T10:30:00',
        end: '2017-05-12T12:30:00'
    },
    {
        title: 'Lunch',
        start: '2017-05-12T12:00:00'
    },
    {
        title: 'Meeting',
        start: '2017-05-12T14:30:00'
    },
    {
        title: 'Dinner',
        start: '2017-05-12T20:00:00'
    },
    


    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2017-05-02'
    },
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2017-05-04'
    },
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2017-05-21',
        end: '2017-05-22'
    },
    {
        id: 999,
        title: 'Repeating Event',
        url: 'http://google.com/',
        start: '2017-05-26T16:00:00'
    },
    {
        id: 999,
        title: 'Repeating Event',
        url: 'http://google.com/',
        start: '2017-05-24T16:00:00'
    },
    {
        title: 'Conference',
        start: '2017-05-11',
        end: '2017-05-13'
    },
    {
        title: 'Meeting',
        start: '2017-05-12T10:30:00',
        end: '2017-05-12T12:30:00'
    },
    {
        title: 'Lunch',
        start: '2017-05-12T12:00:00'
    },
    {
        title: 'Meeting',
        start: '2017-05-12T14:30:00'
    },
    {
        title: 'Dinner',
        start: '2017-05-12T20:00:00'
    },
    


    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2017-03-01'
    },
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2017-03-02'
    },
    {
        title: 'Click for Google',
        url: 'http://google.com/',
        start: '2017-03-21',
        end: '2017-03-22'
    },
    {
        id: 999,
        title: 'Repeating Event',
        url: 'http://google.com/',
        start: '2017-03-23T16:00:00'
    },
    {
        id: 999,
        title: 'Repeating Event',
        url: 'http://google.com/',
        start: '2017-03-23T16:00:00'
    },
    {
        title: 'Conference',
        start: '2017-03-11',
        end: '2017-03-13'
    },
    {
        title: 'Meeting',
        start: '2017-03-12T10:30:00',
        end: '2017-03-12T12:30:00'
    },
    {
        title: 'Lunch',
        start: '2017-03-12T12:00:00'
    },
    {
        title: 'Meeting',
        start: '2017-03-12T14:30:00'
    },
    {
        title: 'Dinner',
        start: '2017-03-12T20:00:00'
    }
];